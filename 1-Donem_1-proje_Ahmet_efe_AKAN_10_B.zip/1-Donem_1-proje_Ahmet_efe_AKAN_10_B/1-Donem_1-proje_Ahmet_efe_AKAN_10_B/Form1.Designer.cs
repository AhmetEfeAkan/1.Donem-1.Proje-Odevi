﻿namespace _1_Donem_1_proje_Ahmet_efe_AKAN_10_B
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.GroupboxSoru1 = new System.Windows.Forms.GroupBox();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.GroupboxSoru2 = new System.Windows.Forms.GroupBox();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.GroupboxSoru3 = new System.Windows.Forms.GroupBox();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.GroupboxSoru4 = new System.Windows.Forms.GroupBox();
            this.radioButton16 = new System.Windows.Forms.RadioButton();
            this.radioButton15 = new System.Windows.Forms.RadioButton();
            this.radioButton14 = new System.Windows.Forms.RadioButton();
            this.radioButton13 = new System.Windows.Forms.RadioButton();
            this.GroupboxSoru5 = new System.Windows.Forms.GroupBox();
            this.radioButton20 = new System.Windows.Forms.RadioButton();
            this.radioButton19 = new System.Windows.Forms.RadioButton();
            this.radioButton18 = new System.Windows.Forms.RadioButton();
            this.radioButton17 = new System.Windows.Forms.RadioButton();
            this.buttonBitir = new System.Windows.Forms.Button();
            this.GroupboxSonuclar = new System.Windows.Forms.GroupBox();
            this.textBoxBasariOrani = new System.Windows.Forms.TextBox();
            this.textBoxYanlis = new System.Windows.Forms.TextBox();
            this.textboxDogru = new System.Windows.Forms.TextBox();
            this.labelyuzde = new System.Windows.Forms.Label();
            this.labelbasariorani = new System.Windows.Forms.Label();
            this.labelyanlis = new System.Windows.Forms.Label();
            this.labeldogru = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.GroupboxSoru1.SuspendLayout();
            this.GroupboxSoru2.SuspendLayout();
            this.GroupboxSoru3.SuspendLayout();
            this.GroupboxSoru4.SuspendLayout();
            this.GroupboxSoru5.SuspendLayout();
            this.GroupboxSonuclar.SuspendLayout();
            this.SuspendLayout();
            // 
            // GroupboxSoru1
            // 
            this.GroupboxSoru1.Controls.Add(this.radioButton4);
            this.GroupboxSoru1.Controls.Add(this.radioButton3);
            this.GroupboxSoru1.Controls.Add(this.radioButton2);
            this.GroupboxSoru1.Controls.Add(this.radioButton1);
            this.GroupboxSoru1.Location = new System.Drawing.Point(53, 83);
            this.GroupboxSoru1.Name = "GroupboxSoru1";
            this.GroupboxSoru1.Size = new System.Drawing.Size(270, 130);
            this.GroupboxSoru1.TabIndex = 0;
            this.GroupboxSoru1.TabStop = false;
            this.GroupboxSoru1.Text = "Soru 1: Türkiye\'nin başkenti olan il hangisidir?";
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(17, 95);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(59, 17);
            this.radioButton4.TabIndex = 3;
            this.radioButton4.Text = "Ankara";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(17, 72);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(51, 17);
            this.radioButton3.TabIndex = 2;
            this.radioButton3.Text = "Sivas";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(17, 49);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(46, 17);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.Text = "İzmir";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(17, 25);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(62, 17);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.Text = "İstanbul";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // GroupboxSoru2
            // 
            this.GroupboxSoru2.Controls.Add(this.radioButton8);
            this.GroupboxSoru2.Controls.Add(this.radioButton7);
            this.GroupboxSoru2.Controls.Add(this.radioButton6);
            this.GroupboxSoru2.Controls.Add(this.radioButton5);
            this.GroupboxSoru2.Location = new System.Drawing.Point(53, 242);
            this.GroupboxSoru2.Name = "GroupboxSoru2";
            this.GroupboxSoru2.Size = new System.Drawing.Size(270, 130);
            this.GroupboxSoru2.TabIndex = 4;
            this.GroupboxSoru2.TabStop = false;
            this.GroupboxSoru2.Text = "Soru 2: Türkiye\'de kaç il vardır?";
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(17, 95);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(37, 17);
            this.radioButton8.TabIndex = 3;
            this.radioButton8.Text = "95";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(17, 72);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(37, 17);
            this.radioButton7.TabIndex = 2;
            this.radioButton7.Text = "81";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(17, 49);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(37, 17);
            this.radioButton6.TabIndex = 1;
            this.radioButton6.Text = "68";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(17, 25);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(37, 17);
            this.radioButton5.TabIndex = 0;
            this.radioButton5.Text = "55";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // GroupboxSoru3
            // 
            this.GroupboxSoru3.Controls.Add(this.radioButton12);
            this.GroupboxSoru3.Controls.Add(this.radioButton11);
            this.GroupboxSoru3.Controls.Add(this.radioButton10);
            this.GroupboxSoru3.Controls.Add(this.radioButton9);
            this.GroupboxSoru3.Location = new System.Drawing.Point(53, 418);
            this.GroupboxSoru3.Name = "GroupboxSoru3";
            this.GroupboxSoru3.Size = new System.Drawing.Size(270, 130);
            this.GroupboxSoru3.TabIndex = 5;
            this.GroupboxSoru3.TabStop = false;
            this.GroupboxSoru3.Text = "Soru 3: Tokat\'ın plaka kodu kaçtır?";
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Location = new System.Drawing.Point(17, 95);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(37, 17);
            this.radioButton12.TabIndex = 3;
            this.radioButton12.Text = "80";
            this.radioButton12.UseVisualStyleBackColor = true;
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Location = new System.Drawing.Point(17, 72);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(37, 17);
            this.radioButton11.TabIndex = 2;
            this.radioButton11.Text = "70";
            this.radioButton11.UseVisualStyleBackColor = true;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Location = new System.Drawing.Point(17, 49);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(37, 17);
            this.radioButton10.TabIndex = 1;
            this.radioButton10.Text = "60";
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(17, 25);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(37, 17);
            this.radioButton9.TabIndex = 0;
            this.radioButton9.Text = "50";
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // GroupboxSoru4
            // 
            this.GroupboxSoru4.Controls.Add(this.radioButton16);
            this.GroupboxSoru4.Controls.Add(this.radioButton15);
            this.GroupboxSoru4.Controls.Add(this.radioButton14);
            this.GroupboxSoru4.Controls.Add(this.radioButton13);
            this.GroupboxSoru4.Location = new System.Drawing.Point(459, 80);
            this.GroupboxSoru4.Name = "GroupboxSoru4";
            this.GroupboxSoru4.Size = new System.Drawing.Size(270, 130);
            this.GroupboxSoru4.TabIndex = 6;
            this.GroupboxSoru4.TabStop = false;
            this.GroupboxSoru4.Text = "Soru 4: Türkiye\'nin en büyük dağı hangisidir?";
            // 
            // radioButton16
            // 
            this.radioButton16.AutoSize = true;
            this.radioButton16.Location = new System.Drawing.Point(17, 95);
            this.radioButton16.Name = "radioButton16";
            this.radioButton16.Size = new System.Drawing.Size(84, 17);
            this.radioButton16.TabIndex = 3;
            this.radioButton16.Text = "Nemrut Dağı";
            this.radioButton16.UseVisualStyleBackColor = true;
            // 
            // radioButton15
            // 
            this.radioButton15.AutoSize = true;
            this.radioButton15.Location = new System.Drawing.Point(17, 72);
            this.radioButton15.Name = "radioButton15";
            this.radioButton15.Size = new System.Drawing.Size(59, 17);
            this.radioButton15.TabIndex = 2;
            this.radioButton15.Text = "Uludağ";
            this.radioButton15.UseVisualStyleBackColor = true;
            // 
            // radioButton14
            // 
            this.radioButton14.AutoSize = true;
            this.radioButton14.Location = new System.Drawing.Point(17, 49);
            this.radioButton14.Name = "radioButton14";
            this.radioButton14.Size = new System.Drawing.Size(84, 17);
            this.radioButton14.TabIndex = 1;
            this.radioButton14.Text = "Erciyes Dağı";
            this.radioButton14.UseVisualStyleBackColor = true;
            // 
            // radioButton13
            // 
            this.radioButton13.AutoSize = true;
            this.radioButton13.Location = new System.Drawing.Point(17, 25);
            this.radioButton13.Name = "radioButton13";
            this.radioButton13.Size = new System.Drawing.Size(68, 17);
            this.radioButton13.TabIndex = 0;
            this.radioButton13.Text = "Ağrı Dağı";
            this.radioButton13.UseVisualStyleBackColor = true;
            // 
            // GroupboxSoru5
            // 
            this.GroupboxSoru5.Controls.Add(this.radioButton20);
            this.GroupboxSoru5.Controls.Add(this.radioButton19);
            this.GroupboxSoru5.Controls.Add(this.radioButton18);
            this.GroupboxSoru5.Controls.Add(this.radioButton17);
            this.GroupboxSoru5.Location = new System.Drawing.Point(459, 242);
            this.GroupboxSoru5.Name = "GroupboxSoru5";
            this.GroupboxSoru5.Size = new System.Drawing.Size(270, 130);
            this.GroupboxSoru5.TabIndex = 7;
            this.GroupboxSoru5.TabStop = false;
            this.GroupboxSoru5.Text = "Soru 5: Tokat hangi bölgededir?";
            // 
            // radioButton20
            // 
            this.radioButton20.AutoSize = true;
            this.radioButton20.Location = new System.Drawing.Point(17, 95);
            this.radioButton20.Name = "radioButton20";
            this.radioButton20.Size = new System.Drawing.Size(63, 17);
            this.radioButton20.TabIndex = 3;
            this.radioButton20.Text = "Akdeniz";
            this.radioButton20.UseVisualStyleBackColor = true;
            // 
            // radioButton19
            // 
            this.radioButton19.AutoSize = true;
            this.radioButton19.Location = new System.Drawing.Point(17, 72);
            this.radioButton19.Name = "radioButton19";
            this.radioButton19.Size = new System.Drawing.Size(72, 17);
            this.radioButton19.TabIndex = 2;
            this.radioButton19.Text = "Karadeniz";
            this.radioButton19.UseVisualStyleBackColor = true;
            // 
            // radioButton18
            // 
            this.radioButton18.AutoSize = true;
            this.radioButton18.Location = new System.Drawing.Point(17, 49);
            this.radioButton18.Name = "radioButton18";
            this.radioButton18.Size = new System.Drawing.Size(44, 17);
            this.radioButton18.TabIndex = 1;
            this.radioButton18.Text = "Ege";
            this.radioButton18.UseVisualStyleBackColor = true;
            // 
            // radioButton17
            // 
            this.radioButton17.AutoSize = true;
            this.radioButton17.Location = new System.Drawing.Point(17, 25);
            this.radioButton17.Name = "radioButton17";
            this.radioButton17.Size = new System.Drawing.Size(66, 17);
            this.radioButton17.TabIndex = 0;
            this.radioButton17.Text = "Marmara";
            this.radioButton17.UseVisualStyleBackColor = true;
            // 
            // buttonBitir
            // 
            this.buttonBitir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonBitir.Location = new System.Drawing.Point(476, 398);
            this.buttonBitir.Name = "buttonBitir";
            this.buttonBitir.Size = new System.Drawing.Size(227, 62);
            this.buttonBitir.TabIndex = 8;
            this.buttonBitir.Text = "Testi Bitir  Sonuçları göster";
            this.buttonBitir.UseVisualStyleBackColor = true;
            this.buttonBitir.Click += new System.EventHandler(this.buttonBitir_Click);
            // 
            // GroupboxSonuclar
            // 
            this.GroupboxSonuclar.Controls.Add(this.textBoxBasariOrani);
            this.GroupboxSonuclar.Controls.Add(this.textBoxYanlis);
            this.GroupboxSonuclar.Controls.Add(this.textboxDogru);
            this.GroupboxSonuclar.Controls.Add(this.labelyuzde);
            this.GroupboxSonuclar.Controls.Add(this.labelbasariorani);
            this.GroupboxSonuclar.Controls.Add(this.labelyanlis);
            this.GroupboxSonuclar.Controls.Add(this.labeldogru);
            this.GroupboxSonuclar.Location = new System.Drawing.Point(433, 479);
            this.GroupboxSonuclar.Name = "GroupboxSonuclar";
            this.GroupboxSonuclar.Size = new System.Drawing.Size(333, 130);
            this.GroupboxSonuclar.TabIndex = 8;
            this.GroupboxSonuclar.TabStop = false;
            this.GroupboxSonuclar.Text = "Sonuçlar";
            this.GroupboxSonuclar.Enter += new System.EventHandler(this.GroupboxSonuclar_Enter);
            // 
            // textBoxBasariOrani
            // 
            this.textBoxBasariOrani.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBoxBasariOrani.Location = new System.Drawing.Point(170, 85);
            this.textBoxBasariOrani.Name = "textBoxBasariOrani";
            this.textBoxBasariOrani.ReadOnly = true;
            this.textBoxBasariOrani.Size = new System.Drawing.Size(100, 21);
            this.textBoxBasariOrani.TabIndex = 6;
            this.textBoxBasariOrani.TabStop = false;
            this.textBoxBasariOrani.Text = "0";
            // 
            // textBoxYanlis
            // 
            this.textBoxYanlis.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBoxYanlis.Location = new System.Drawing.Point(170, 54);
            this.textBoxYanlis.Name = "textBoxYanlis";
            this.textBoxYanlis.ReadOnly = true;
            this.textBoxYanlis.Size = new System.Drawing.Size(100, 21);
            this.textBoxYanlis.TabIndex = 5;
            this.textBoxYanlis.TabStop = false;
            this.textBoxYanlis.Text = "0";
            // 
            // textboxDogru
            // 
            this.textboxDogru.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textboxDogru.Location = new System.Drawing.Point(170, 24);
            this.textboxDogru.Name = "textboxDogru";
            this.textboxDogru.ReadOnly = true;
            this.textboxDogru.Size = new System.Drawing.Size(100, 21);
            this.textboxDogru.TabIndex = 4;
            this.textboxDogru.TabStop = false;
            this.textboxDogru.Text = "0";
            // 
            // labelyuzde
            // 
            this.labelyuzde.AutoSize = true;
            this.labelyuzde.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            this.labelyuzde.ForeColor = System.Drawing.Color.Fuchsia;
            this.labelyuzde.Location = new System.Drawing.Point(143, 86);
            this.labelyuzde.Name = "labelyuzde";
            this.labelyuzde.Size = new System.Drawing.Size(21, 17);
            this.labelyuzde.TabIndex = 3;
            this.labelyuzde.Text = "%";
            this.labelyuzde.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.labelyuzde.Click += new System.EventHandler(this.labelyuzde_Click);
            // 
            // labelbasariorani
            // 
            this.labelbasariorani.AutoSize = true;
            this.labelbasariorani.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            this.labelbasariorani.ForeColor = System.Drawing.Color.Fuchsia;
            this.labelbasariorani.Location = new System.Drawing.Point(16, 86);
            this.labelbasariorani.Name = "labelbasariorani";
            this.labelbasariorani.Size = new System.Drawing.Size(104, 17);
            this.labelbasariorani.TabIndex = 2;
            this.labelbasariorani.Text = "Başarı Oranı:";
            this.labelbasariorani.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelyanlis
            // 
            this.labelyanlis.AutoSize = true;
            this.labelyanlis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            this.labelyanlis.ForeColor = System.Drawing.Color.Fuchsia;
            this.labelyanlis.Location = new System.Drawing.Point(16, 56);
            this.labelyanlis.Name = "labelyanlis";
            this.labelyanlis.Size = new System.Drawing.Size(110, 17);
            this.labelyanlis.TabIndex = 1;
            this.labelyanlis.Text = "Yanlış  Sayısı:";
            this.labelyanlis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labeldogru
            // 
            this.labeldogru.AutoSize = true;
            this.labeldogru.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            this.labeldogru.ForeColor = System.Drawing.Color.Fuchsia;
            this.labeldogru.Location = new System.Drawing.Point(16, 25);
            this.labeldogru.Name = "labeldogru";
            this.labeldogru.Size = new System.Drawing.Size(105, 17);
            this.labeldogru.TabIndex = 0;
            this.labeldogru.Text = "Doğru Sayısı:";
            this.labeldogru.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(302, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 31);
            this.label1.TabIndex = 9;
            this.label1.Text = "Başarı Testi";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 646);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.GroupboxSonuclar);
            this.Controls.Add(this.buttonBitir);
            this.Controls.Add(this.GroupboxSoru5);
            this.Controls.Add(this.GroupboxSoru4);
            this.Controls.Add(this.GroupboxSoru3);
            this.Controls.Add(this.GroupboxSoru2);
            this.Controls.Add(this.GroupboxSoru1);
            this.Name = "Form1";
            this.Text = "Form1 - Test Sınavı";
            this.GroupboxSoru1.ResumeLayout(false);
            this.GroupboxSoru1.PerformLayout();
            this.GroupboxSoru2.ResumeLayout(false);
            this.GroupboxSoru2.PerformLayout();
            this.GroupboxSoru3.ResumeLayout(false);
            this.GroupboxSoru3.PerformLayout();
            this.GroupboxSoru4.ResumeLayout(false);
            this.GroupboxSoru4.PerformLayout();
            this.GroupboxSoru5.ResumeLayout(false);
            this.GroupboxSoru5.PerformLayout();
            this.GroupboxSonuclar.ResumeLayout(false);
            this.GroupboxSonuclar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox GroupboxSoru1;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.GroupBox GroupboxSoru2;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.GroupBox GroupboxSoru3;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.GroupBox GroupboxSoru4;
        private System.Windows.Forms.RadioButton radioButton16;
        private System.Windows.Forms.RadioButton radioButton15;
        private System.Windows.Forms.RadioButton radioButton14;
        private System.Windows.Forms.RadioButton radioButton13;
        private System.Windows.Forms.GroupBox GroupboxSoru5;
        private System.Windows.Forms.RadioButton radioButton20;
        private System.Windows.Forms.RadioButton radioButton19;
        private System.Windows.Forms.RadioButton radioButton18;
        private System.Windows.Forms.RadioButton radioButton17;
        private System.Windows.Forms.Button buttonBitir;
        private System.Windows.Forms.GroupBox GroupboxSonuclar;
        private System.Windows.Forms.TextBox textBoxBasariOrani;
        private System.Windows.Forms.TextBox textBoxYanlis;
        private System.Windows.Forms.TextBox textboxDogru;
        private System.Windows.Forms.Label labelyuzde;
        private System.Windows.Forms.Label labelbasariorani;
        private System.Windows.Forms.Label labelyanlis;
        private System.Windows.Forms.Label labeldogru;
        private System.Windows.Forms.Label label1;
    }
}

